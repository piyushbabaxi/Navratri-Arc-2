NAVRATRI ARC — ANDROID PROJECT + MOBILE CLOUD BUILD

You do not need a PC to request a cloud build, but you do need a GitHub account and a mobile browser.

MOBILE STEPS
1. Download and extract this ZIP on your phone if possible. If your file manager cannot extract it, use a trusted ZIP utility.
2. In your phone browser, sign in to github.com and create a new repository. A public repository is the simplest option for this workflow; do not upload private secrets.
3. Upload the extracted project files/folders into the repository, preserving the folder structure. The .github/workflows/build-apk.yml file must be included. Upload the CONTENTS of NavratriArcAndroid, not the outer parent folder.
4. Open the repository's Actions tab. Choose “Build GTA Piyush APK” and tap “Run workflow” if it has not started automatically after the files were pushed to the main branch.
5. Wait for the workflow to finish with a green check mark. Open that run and find “Artifacts”. Download “navratri-arc-debug-apk”.
6. Extract the downloaded artifact ZIP to get app-debug.apk. Tap the APK to install it. Android may ask you to allow installation from that browser or file manager; only enable this for the app you used to download the file, and turn it off again afterward.

NOTES
- This is a debug APK, not a Play Store release.
- The app stores habit data in the app's local WebView storage on your device. Uninstalling the app or clearing its storage may erase the data; use the app's export/backup option if available.
- GitHub's interface can be awkward on mobile. If uploading folders is difficult, tell ChatGPT which step is blocking you and use a phone-friendly repository upload method.

Updated version: weekly progress is now a vertical bar chart with percentages below each day; added a 0–15,000 steps slider; supplied logo is used as the Android launcher icon.
